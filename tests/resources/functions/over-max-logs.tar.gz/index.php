<?php

$string = 'x';

echo str_repeat($string, 65535);