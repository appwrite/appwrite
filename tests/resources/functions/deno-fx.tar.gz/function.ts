import { config } from 'https://deno.land/x/dotenv/mod.ts';

console.log('Hello Wolrd');

console.log(config());
