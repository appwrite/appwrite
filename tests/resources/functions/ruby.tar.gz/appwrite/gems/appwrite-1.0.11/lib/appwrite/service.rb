module Appwrite
    class Service

        def initialize(client)
            @client = client
        end
        
        protected

        private
    end 
end