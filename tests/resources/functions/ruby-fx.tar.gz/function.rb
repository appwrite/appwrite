require 'pp'

puts 'Hello, world!'

pp ENV
