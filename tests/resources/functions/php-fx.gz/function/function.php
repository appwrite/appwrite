<?php

echo "Hello World";

var_dump($_ENV);
