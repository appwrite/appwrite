<?php

return function ($request, $response) {
    sleep(5);
};