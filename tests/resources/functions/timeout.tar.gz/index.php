<?php

sleep(10);