import os

print("Hello world")

print(os.environ)
