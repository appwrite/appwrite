import os

print("Hello world")

for k, v in sorted(os.environ.items()):
    print(k+':', v)
print('\n')
